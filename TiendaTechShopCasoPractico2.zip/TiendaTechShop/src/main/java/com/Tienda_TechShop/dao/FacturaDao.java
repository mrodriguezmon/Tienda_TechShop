package com.Tienda_TechShop.dao;

import com.Tienda_TechShop.domain.Factura;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FacturaDao extends JpaRepository<Factura, Long> {
    
}
