
package com.Tienda_TechShop.dao;

import com.Tienda_TechShop.domain.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoriaDao extends JpaRepository <Categoria,Long>{
    
}
