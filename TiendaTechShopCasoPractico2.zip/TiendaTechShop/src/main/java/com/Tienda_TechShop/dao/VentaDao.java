
package com.Tienda_TechShop.dao;

import com.Tienda_TechShop.domain.Venta;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VentaDao extends JpaRepository<Venta, Long>{
    
}
