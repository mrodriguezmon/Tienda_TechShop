
package com.Tienda_TechShop.dao;

import com.Tienda_TechShop.domain.Rol;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RolDao extends JpaRepository<Rol, Long> {
    
}
