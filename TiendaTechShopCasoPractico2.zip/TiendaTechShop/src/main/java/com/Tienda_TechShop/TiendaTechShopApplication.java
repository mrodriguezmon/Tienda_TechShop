package com.Tienda_TechShop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TiendaTechShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(TiendaTechShopApplication.class, args);
	}

}
